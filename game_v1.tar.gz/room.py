
class Room(object):
    def __init__(self, id, version, players):
        self.id = id
        self.version = version
        self.players = players
        #self.state = state
